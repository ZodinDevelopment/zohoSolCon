OAUTH_DATA = {}

OAUTH_DATA["client_id"] = ""  				 # paste client ID here
OAUTH_DATA["client_secret"] = "" # Past client secret herer
OAUTH_DATA["grant_token"] = ""    ### lastly paste your grant token here 
